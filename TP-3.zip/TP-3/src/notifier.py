def send_notification(message):
    """
    Envoie une notification pour alerter un problème de température.
    """
    print(f"Notification: {message}")
