# Configuration des seuils de température, ou tout autres valeurs globales
MIN_TEMP_THRESHOLD = 0
MAX_TEMP_THRESHOLD = 100
# Vous pouvez facilement changer ces valeurs..